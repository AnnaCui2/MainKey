package com.example.mjcan.mainkey


private class Admin_Class {
    /*
    User information to log into the app
     */
    var admin_login: String? = null
    var admin_password: String? = null
}