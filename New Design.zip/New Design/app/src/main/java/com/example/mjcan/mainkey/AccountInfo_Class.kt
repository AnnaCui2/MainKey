package com.example.mjcan.mainkey

class AccountInformation(accName: String, accUsername: String, accPass: String, count: Int) {
    /*
    Info for each account entry created by the user
     */
    var account_name : String? = null
    var account_email: String? = null
    var account_password : String? = null
}



