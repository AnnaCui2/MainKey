# MainKey

## Cmpe131 Application Project 

## Group No. : 6

## Created by:
- Anna Cui
- João Carlos Prado
- Michael Ancheta
- Nick Castro

## Description:
Our group, group 6, will use this platform to make an application available on android phones that will be used as a database to remember the user's passwords for their login in other applications.
We will be coding on android studio and transfering the code to GitHub where we can all collaborate. 
