package com.example.joaocarlos.recyclerview

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

var mlist = mutableListOf<AccountDB>()


class AddActivity : AppCompatActivity() {

    var count: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        /*
            Save button:
            Pressing button saves the information and takes user back to Main Activity
         */
        val savebtn: Button = findViewById(R.id.save_btn)
        savebtn.setOnClickListener {
            var label = findViewById<EditText>(R.id.label).getText().toString()
            var login = findViewById<EditText>(R.id.login).getText().toString()
            var password = findViewById<EditText>(R.id.password).getText().toString()
            count += 1

            var tempAcc = AccountDB(count, label, login, password)

            if(mlist.add(tempAcc)){
                Toast.makeText(this, "Item: " + tempAcc.label + " created", Toast.LENGTH_LONG).show()
            }


            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
