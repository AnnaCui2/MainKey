package com.example.joaocarlos.recyclerview

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        /*
            Add Button:
            Pressing button will lead to activity
            to create a new entry
         */
        var addEntryBtn = findViewById(R.id.add_btn) as FloatingActionButton
        addEntryBtn.setOnClickListener{
            val intent = Intent(this, AddActivity::class.java)
            startActivity(intent)
        }


        /*
            Recycler view:
            List with accounts that are stored
         */
        val recyclerView: RecyclerView = findViewById(R.id.note_list_recyclerview)
        val layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        val dividerItemDecoration = DividerItemDecoration(recyclerView.context, layoutManager.orientation)
        recyclerView.addItemDecoration(dividerItemDecoration)
        recyclerView.adapter = MyAdapter(Macc(mlist), { item: AccountDB -> itemClicked(item) }, this)
    }

    private fun itemClicked(item : AccountDB) {
        Toast.makeText(this, "Clicked: ${item.label}", Toast.LENGTH_LONG).show()
        val intent = Intent(this, InfoActivity::class.java)
        intent.putExtra(Intent.EXTRA_TEXT, item)
        startActivity(intent)
    }

    private fun Macc(mutableList: MutableList<AccountDB>) : MutableList<AccountDB> {
        if(mutableList.isEmpty()){
            return mutableListOf(
                AccountDB(1, "Your accounts will be displayed here","login 1", "password 1")
            )
        }
        else{
            return mutableList
        }
    }
}

