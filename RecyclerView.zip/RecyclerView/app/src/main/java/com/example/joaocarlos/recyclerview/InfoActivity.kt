package com.example.joaocarlos.recyclerview

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_info.*

class InfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)

        var intentParent = getIntent()

        if (intentParent.hasExtra(Intent.EXTRA_TEXT)) {
            var itemID = intentParent.getParcelableExtra<AccountDB>(Intent.EXTRA_TEXT)
            info_label.text = itemID.label
            info_login.text = itemID.login
            info_password.text = itemID.password
        }
    }
}
