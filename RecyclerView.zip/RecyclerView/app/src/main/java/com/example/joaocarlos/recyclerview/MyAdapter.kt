package com.example.joaocarlos.recyclerview


import android.content.Context
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.RecyclerView.Adapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.list_item.view.*

class MyAdapter(private var list: MutableList<AccountDB>, val clickListener: (AccountDB) -> Unit,
                private val context: Context) : Adapter<MyAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val acc = list[position]
        holder.title.text = acc.login
        holder.bind(list[position], clickListener)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title = itemView.note_item_title!!
        fun bind(info: AccountDB, clickListener: (AccountDB) -> Unit){
            itemView.note_item_title.text = info.label
            itemView.setOnClickListener{clickListener(info)}
        }
    }
}


