package com.example.joaocarlos.recyclerview

import android.os.Parcel
import android.os.Parcelable


data class AccountDB(var id: Int, var label: String, var login: String, var password: String) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(label)
        parcel.writeString(login)
        parcel.writeString(password)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<AccountDB> {
        override fun createFromParcel(parcel: Parcel): AccountDB {
            return AccountDB(parcel)
        }

        override fun newArray(size: Int): Array<AccountDB?> {
            return arrayOfNulls(size)
        }
    }

}