package com.example.joaocarlos.myapplication

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_create_login.*

var LoginItemList: MutableList<LoginList>? = null
lateinit var adapter: AdapterClass
private var listViewItems: ListView? = null


class MainActivity : AppCompatActivity() {

    private var db = FirebaseDatabase.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*
        * FloatingActionButton
        * Goes to the activity with input for information
        * */




        var addButton = findViewById<View>(R.id.addButton) as FloatingActionButton
        val intent = Intent(this, CreateLogin::class.java)
        addButton.setOnClickListener {
            startActivity(intent)
        }

        mDatabase = FirebaseDatabase.getInstance().reference
        LoginItemList = mutableListOf<LoginList>()
        adapter = AdapterClass(this, LoginItemList!!)
        listViewItems!!.setAdapter(adapter)
        mDatabase.orderByKey().addListenerForSingleValueEvent(itemListener)
    }

    var itemListener: ValueEventListener = object : ValueEventListener {
        override fun onCancelled(p0: DatabaseError) {
            Log.w("Main Activity", "loaditem:onCancelled", p0.toException())
        }

        override fun onDataChange(p0: DataSnapshot) {
            addDataToList(p0)
        }

        private fun addDataToList(dataSnapshot: DataSnapshot){
            val items = dataSnapshot.children.iterator()
            if(items.hasNext()){
                val loginListIndex = items.next()
                val itemsIterator = loginListIndex.children.iterator()

                while (itemsIterator.hasNext()){
                    val currentItem = itemsIterator.next()
                    val loginItem = LoginList.create()

                    val map = currentItem.getValue() as HashMap<String, Any>

                    loginItem.objectID = currentItem.key
                    loginItem.accountLabel = map.get("accountLabel") as String
                    loginItem.passwordInfo = map.get("passwordInfo") as String
                    loginItem.loginInfo = map.get("loginInfo") as String

                    LoginItemList!!.add(loginItem)
                }
            }
        adapter.notifyDataSetChanged()
        }
    }
}

class AdapterClass (context: Context, LoginItemList: MutableList<LoginList>) : BaseAdapter() {

    private val mInflater: LayoutInflater = LayoutInflater.from(context)
    private var itemList = LoginItemList
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val objectID: String = itemList.get(position).objectID as String
        val label: String = itemList.get(position).accountLabel as String
        val login: String = itemList.get(position).loginInfo as String
        val password: String = itemList.get(position).passwordInfo as String

        val view: View
        val vh: ListRowHolder

        if (convertView == null){
            view = mInflater.inflate(R.layout.row_items, parent, false)
            vh = ListRowHolder(view)
//            view.tag as ListRowHolder
            view.tag = vh
        }else{
            view = convertView
            vh = view.tag as ListRowHolder
        }

        vh.label.text = label
        return view

    }
    override fun getItem(position: Int): Any {
        return itemList.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return itemList.size
    }
    private class ListRowHolder(row: View) {
        val label: TextView
        init {
            this.label = row.findViewById(R.id.tv_item_text)
        }
    }
}






