package com.example.joaocarlos.myapplication

object Constants {
    @JvmStatic val FIREBASE_ITEM: String = "login"
}

class LoginList {

    companion object Factory {
        fun create(): LoginList = LoginList()
    }

    var objectID: String? = null
    var accountLabel: String? = null
    var loginInfo: String? = null
    var passwordInfo: String? = null
}