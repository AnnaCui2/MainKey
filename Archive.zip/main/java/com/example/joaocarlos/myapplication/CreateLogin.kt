package com.example.joaocarlos.myapplication

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

lateinit var mDatabase: DatabaseReference

class CreateLogin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_login)

        val saveButton = findViewById<Button>(R.id.SaveButton)

        mDatabase = FirebaseDatabase.getInstance().reference

        saveButton.setOnClickListener(){
            val intent = Intent(this, MainActivity::class.java)
            addNewItem()
            startActivity(intent)
        }


    }

    private fun addNewItem(){
        val usrInfo = LoginList.create()
        val label = findViewById<EditText>(R.id.accountLabel) as EditText
        val login = findViewById<EditText>(R.id.login) as EditText
        val password = findViewById<EditText>(R.id.password) as EditText
        usrInfo.accountLabel = label.text.toString()
        usrInfo.loginInfo = login.text.toString()
        usrInfo.passwordInfo = password.text.toString()


        val newItem = mDatabase.child(Constants.FIREBASE_ITEM).push()
        usrInfo.objectID = newItem.key

        newItem.setValue(usrInfo)

        Toast.makeText(this, "Item saved with ID: " + usrInfo.objectID, Toast.LENGTH_LONG).show()
    }


}
